﻿using System.Data.Entity;

namespace Videos.Models
{
    public class VideoDb : DbContext
    {
        public DbSet<Video> Videos { get; set; }        
    }
}